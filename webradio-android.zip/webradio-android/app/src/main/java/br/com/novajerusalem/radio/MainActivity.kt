package br.com.novajerusalem.radio

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.webkit.WebViewAssetLoader
import com.google.common.util.concurrent.MoreExecutors

class MainActivity : Activity() {

    private lateinit var webView: WebView
    private var controller: MediaController? = null
    @Volatile private var estadoAtual = "pausado"
    private var tocarAoConectar = false

    private val host = "appassets.androidplatform.net"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF1E1E1E.toInt()
        window.navigationBarColor = 0xFF111111.toInt()

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val assetLoader = WebViewAssetLoader.Builder()
            .setDomain(host)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this)
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
        }
        webView.setBackgroundColor(0xFF111111.toInt())
        webView.addJavascriptInterface(Ponte(), "AndroidRadio")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (request.url.host == host) return false
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, request.url))
                } catch (_: Exception) {}
                return true
            }
        }

        webView.loadUrl("https://$host/assets/www/index.html")
        conectarServico()
    }

    private fun conectarServico() {
        val token = SessionToken(this, ComponentName(this, RadioService::class.java))
        val futuro = MediaController.Builder(this, token).buildAsync()
        futuro.addListener({
            val c = futuro.get()
            controller = c
            c.addListener(object : Player.Listener {
                override fun onEvents(player: Player, events: Player.Events) = enviarEstado(player)
            })
            enviarEstado(c)
            if (tocarAoConectar) {
                tocarAoConectar = false
                RadioService.instance?.iniciar()
            }
        }, MoreExecutors.directExecutor())
    }

    private fun enviarEstado(p: Player) {
        estadoAtual = when {
            p.isPlaying -> "tocando"
            p.playWhenReady && p.playbackState != Player.STATE_ENDED -> "carregando"
            else -> "pausado"
        }
        webView.evaluateJavascript(
            "window.nativeRadioState && window.nativeRadioState('$estadoAtual')", null
        )
    }

    /** Funções que o site chama (chegam em outra thread, por isso runOnUiThread). */
    inner class Ponte {
        @JavascriptInterface
        fun play() = runOnUiThread {
            // O serviço é criado ao conectar o controller; ao tocar, ele sobe em primeiro plano sozinho
            val servico = RadioService.instance
            if (servico != null) {
                servico.iniciar()
            } else {
                tocarAoConectar = true
                if (controller == null) conectarServico()
            }
        }

        @JavascriptInterface
        fun pause() = runOnUiThread { controller?.pause() }

        @JavascriptInterface
        fun getState(): String = estadoAtual

        @JavascriptInterface
        fun setSleepTimer(minutos: Int) {
            RadioService.instance?.definirTimer(minutos)
        }

        @JavascriptInterface
        fun share(texto: String) = runOnUiThread {
            val i = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, texto)
            }
            startActivity(Intent.createChooser(i, "Compartilhar"))
        }
    }

    // Botão voltar: não fecha o app, só minimiza (a rádio continua)
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        moveTaskToBack(true)
    }

    override fun onDestroy() {
        controller?.release()
        controller = null
        webView.destroy()
        super.onDestroy()
    }
}
