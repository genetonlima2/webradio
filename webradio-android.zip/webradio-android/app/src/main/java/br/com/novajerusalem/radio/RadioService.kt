package br.com.novajerusalem.radio

import android.app.PendingIntent
import android.content.Intent
import android.os.Handler
import android.os.Looper
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/**
 * Serviço em primeiro plano (com notificação) que mantém a rádio tocando
 * com a tela apagada ou com o app fechado.
 */
class RadioService : MediaSessionService() {

    companion object {
        const val STREAM_URL = "https://stream.zeno.fm/qayal7hvb6ftv"
        const val RADIO_NOME = "Web Rádio Nova Jerusalém"
        @Volatile var instance: RadioService? = null
    }

    private var session: MediaSession? = null
    private lateinit var player: ExoPlayer
    private val handler = Handler(Looper.getMainLooper())
    private var tentativas = 0

    private val timerRunnable = Runnable { player.pause() }

    private val reconectar = Runnable {
        if (player.playWhenReady) {
            player.setMediaItem(criarItem())
            player.prepare()
        }
    }

    private fun criarItem(): MediaItem =
        MediaItem.Builder()
            .setUri("$STREAM_URL?live=${System.currentTimeMillis()}")
            .setMediaMetadata(
                MediaMetadata.Builder()
                    .setTitle(RADIO_NOME)
                    .setArtist("Ao vivo 24 horas")
                    .setIsPlayable(true)
                    .build()
            )
            .build()

    override fun onCreate() {
        super.onCreate()
        instance = this

        player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                true // pausa em ligação e volta depois
            )
            .setHandleAudioBecomingNoisy(true) // pausa ao desconectar fone
            .setWakeMode(C.WAKE_MODE_NETWORK)  // mantém CPU e Wi-Fi ativos tocando
            .build()

        player.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                // Stream caiu: tenta reconectar com espera crescente
                tentativas++
                val espera = minOf(15000L, 2000L * tentativas)
                handler.removeCallbacks(reconectar)
                handler.postDelayed(reconectar, espera)
            }

            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) tentativas = 0
                if (state == Player.STATE_ENDED && player.playWhenReady) {
                    handler.removeCallbacks(reconectar)
                    handler.postDelayed(reconectar, 2000)
                }
            }
        })

        val abrirApp = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        session = MediaSession.Builder(this, player)
            .setSessionActivity(abrirApp)
            .build()
    }

    /** Temporizador para dormir: pausa a rádio após [minutos]. 0 cancela. */
    fun definirTimer(minutos: Int) {
        handler.post {
            handler.removeCallbacks(timerRunnable)
            if (minutos > 0) handler.postDelayed(timerRunnable, minutos * 60_000L)
        }
    }

    /** Começa (ou recomeça) a transmissão ao vivo. */
    fun iniciar() {
        handler.post {
            tentativas = 0
            handler.removeCallbacks(reconectar)
            player.setMediaItem(criarItem())
            player.prepare()
            player.play()
        }
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    // App removido dos recentes: continua tocando; se estiver pausado, encerra o serviço
    override fun onTaskRemoved(rootIntent: Intent?) {
        if (!player.playWhenReady) stopSelf()
    }

    override fun onDestroy() {
        instance = null
        handler.removeCallbacksAndMessages(null)
        session?.run {
            player.release()
            release()
        }
        session = null
        super.onDestroy()
    }
}
