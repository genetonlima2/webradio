(() => {

  'use strict';



  const STREAM_URL = 'https://stream.zeno.fm/qayal7hvb6ftv';

  const METADATA_SSE_URL = 'https://api.zeno.fm/mounts/metadata/subscribe/qayal7hvb6ftv';

  const RADIO_NOME = 'Web Rádio Nova Jerusalém';

  const FALLBACK_TITULO = 'Programação 24 horas — Ao Vivo';



  const player = document.getElementById('player');

  const playBtn = document.getElementById('play_btn');

  const statusBadge = document.getElementById('status_badge');

  const statusTexto = document.getElementById('status_texto');

  const npTitulo = document.getElementById('np_titulo');

  const splash = document.getElementById('splash');



  const volumeSlider = document.getElementById('volume_slider');

  const muteBtn = document.getElementById('mute_btn');



  const igrejaBtn = document.getElementById('igreja_btn');

  const igrejaSheet = document.getElementById('igreja_sheet');

  const igrejaFechar = document.getElementById('igreja_fechar');

  const overlay = document.getElementById('igreja_overlay');



  const timerBtn = document.getElementById('timer_btn');

  const timerLabel = document.getElementById('timer_label');

  const timerSheet = document.getElementById('timer_sheet');

  const timerFechar = document.getElementById('timer_fechar');



  const compartilharBtn = document.getElementById('compartilhar_btn');

  const instalarBtn = document.getElementById('instalar_btn');

  const bateriaCard = document.getElementById('bateria_card');

  const bateriaLiberar = document.getElementById('bateria_liberar');

  const bateriaDepois = document.getElementById('bateria_depois');

  const toastEl = document.getElementById('toast');

  // Dentro do app Android (APK) existe a ponte "AndroidRadio": o áudio toca no serviço nativo.
  const NATIVO = typeof window.AndroidRadio !== 'undefined';
  // Endereço que será compartilhado no WhatsApp quando estiver no app. Altere para o link da sua rádio.
  const SHARE_URL = 'https://adnovajerusalem.com.br';



  let querTocar = false;

  let estaReconectando = false;

  let musicaAtual = FALLBACK_TITULO;

  let tentativasReconexao = 0;

  let reconnectTimeout = null;

  let fadeInterval = null;

  let toastTimeout = null;

  let deferredPrompt = null;

  let sseConexao = null;

  let ultimoTempo = -1;

  let segundosTravado = 0;
  let pausaInterna = false;



  const VERSICULOS = [

    { texto: 'O Senhor é o meu pastor; nada me faltará.', ref: 'Salmos 23:1' },

    { texto: 'Tudo posso naquele que me fortalece.', ref: 'Filipenses 4:13' },

    { texto: 'Entrega o teu caminho ao Senhor; confia nele, e ele tudo fará.', ref: 'Salmos 37:5' },

    { texto: 'Porque Deus amou o mundo de tal maneira que deu o seu Filho unigênito.', ref: 'João 3:16' },

    { texto: 'Lâmpada para os meus pés é tua palavra e luz, para o meu caminho.', ref: 'Salmos 119:105' },

    { texto: 'Buscai primeiro o Reino de Deus, e a sua justiça, e todas essas coisas vos serão acrescentadas.', ref: 'Mateus 6:33' },

    { texto: 'Alegrai-vos sempre no Senhor; outra vez digo, alegrai-vos.', ref: 'Filipenses 4:4' },

    { texto: 'O Senhor é a minha luz e a minha salvação; a quem temerei?', ref: 'Salmos 27:1' },

    { texto: 'Mil cairão ao teu lado, e dez mil, à tua direita, mas tu não serás atingido.', ref: 'Salmos 91:7' },

    { texto: 'Vinde a mim, todos os que estais cansados e oprimidos, e eu vos aliviarei.', ref: 'Mateus 11:28' }

  ];



  function carregarVersiculoDoDia() {

    const hoje = new Date();

    const indice = Math.floor(hoje.getTime() / 86400000) % VERSICULOS.length;

    const v = VERSICULOS[indice];

    document.getElementById('versiculo_texto').textContent = `"${v.texto}"`;

    document.getElementById('versiculo_ref').textContent = v.ref;

  }



  function mostrarToast(msg, duracao = 3200) {

    toastEl.textContent = msg;

    toastEl.classList.add('visivel');

    clearTimeout(toastTimeout);

    toastTimeout = setTimeout(() => toastEl.classList.remove('visivel'), duracao);

  }



  function atualizarMediaSessionEstado(state) {
    if ('mediaSession' in navigator) {
      try {
        navigator.mediaSession.playbackState = state;
      } catch (_) {}
    }
  }

  function configurarMediaSession() {
    if (NATIVO || !('mediaSession' in navigator)) return;

    try {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: musicaAtual || RADIO_NOME,
        artist: RADIO_NOME,
        album: 'Transmissão Ao Vivo 24h',
        artwork: [
          { src: new URL('assets/icon-192.png', document.baseURI).href, sizes: '192x192', type: 'image/png' },
          { src: new URL('assets/icon-512.png', document.baseURI).href, sizes: '512x512', type: 'image/png' }
        ]
      });
    } catch (_) {}

    const acoes = [
      ['play', () => { if (!querTocar || player.paused) iniciarStream(true); }],
      ['pause', pausarRadio],
      ['stop', pausarRadio]
    ];
    acoes.forEach(([acao, fn]) => {
      try { navigator.mediaSession.setActionHandler(acao, fn); } catch (_) {}
    });
  }

  function atualizarEstadoUI(estado) {

    document.body.classList.remove('is-playing', 'is-loading');

    statusBadge.className = '';



    if (estado === 'tocando') {

      document.body.classList.add('is-playing');

      statusBadge.classList.add('status-tocando');

      statusTexto.textContent = 'Ao Vivo';

      playBtn.setAttribute('aria-label', 'Pausar rádio');

      playBtn.setAttribute('aria-pressed', 'true');

    } else if (estado === 'carregando') {

      document.body.classList.add('is-loading');

      statusBadge.classList.add('status-carregando');

      statusTexto.textContent = 'Conectando...';

      playBtn.setAttribute('aria-label', 'Conectando...');

    } else if (estado === 'reconectando') {

      document.body.classList.add('is-loading');

      statusBadge.classList.add('status-carregando');

      statusTexto.textContent = 'Reconectando...';

    } else {

      statusBadge.classList.add('status-pausado');

      statusTexto.textContent = 'Toque para ouvir';

      playBtn.setAttribute('aria-label', 'Tocar rádio');

      playBtn.setAttribute('aria-pressed', 'false');

    }



    atualizarMediaSessionEstado(estado === 'tocando' ? 'playing' : (estado === 'pausado' ? 'paused' : 'none'));

  }



  function fadeAudio(alvo, duracaoMs = 450, aoFinal = null) {

    clearInterval(fadeInterval);

    const inicio = player.volume;

    const passos = 15;

    let atual = 0;



    fadeInterval = setInterval(() => {

      atual++;

      try {

        player.volume = Math.max(0, Math.min(1, inicio + (alvo - inicio) * (atual / passos)));

      } catch (_) {}

      if (atual >= passos) {

        clearInterval(fadeInterval);

        if (aoFinal) aoFinal();

      }

    }, duracaoMs / passos);

  }



  function obterVolumeSalvo() {

    const salvo = parseFloat(localStorage.getItem('nj_volume'));

    return Number.isFinite(salvo) ? Math.max(0, Math.min(1, salvo)) : 1;

  }



  async function iniciarStream(ehReconexao = false) {
    if (NATIVO) {
      if (ehReconexao) return; // o serviço nativo reconecta sozinho
      querTocar = true;
      atualizarEstadoUI('carregando');
      window.AndroidRadio.play();
      return;
    }

    querTocar = true;

    estaReconectando = ehReconexao;


    clearTimeout(reconnectTimeout);

    clearInterval(fadeInterval);

    atualizarEstadoUI(ehReconexao ? 'reconectando' : 'carregando');



    if (!ehReconexao) {

      player.pause();

      player.removeAttribute('src');

      player.load();

    }



    player.src = `${STREAM_URL}?live=${Date.now()}`;

    if (ehReconexao) player.load();



    const volAlvo = player.muted ? 0 : obterVolumeSalvo();

    try { player.volume = ehReconexao ? volAlvo : 0; } catch (_) {}



    try {

      await player.play();

      tentativasReconexao = 0;

      estaReconectando = false;

      atualizarEstadoUI('tocando');

      if (!ehReconexao) fadeAudio(volAlvo, 500);

      configurarMediaSession();

    } catch (_) {

      estaReconectando = false;

      if (ehReconexao && querTocar) {

        agendarReconexao();

      } else if (querTocar) {

        atualizarEstadoUI('pausado');

        querTocar = false;

        mostrarToast('Não foi possível iniciar o áudio. Verifique sua conexão.');

      }

    }

  }



  function pausarRadio() {
    if (NATIVO) {
      querTocar = false;
      atualizarEstadoUI('pausado');
      window.AndroidRadio.pause();
      return;
    }

    querTocar = false;

    estaReconectando = false;


    clearTimeout(reconnectTimeout);

    clearInterval(fadeInterval);



    fadeAudio(0, 260, () => {

      player.pause();

      atualizarEstadoUI('pausado');

    });

  }



  function agendarReconexao() {

    if (!querTocar || estaReconectando) return;

    estaReconectando = true;

    clearTimeout(reconnectTimeout);



    tentativasReconexao++;

    const espera = Math.min(15000, 2000 * Math.pow(1.4, tentativasReconexao - 1));

    atualizarEstadoUI('reconectando');



    reconnectTimeout = setTimeout(() => {

      estaReconectando = false;

      if (querTocar && navigator.onLine) {

        iniciarStream(true);

      } else if (querTocar) {

        agendarReconexao();

      }

    }, espera);

  }



  playBtn.addEventListener('click', () => {

    if (querTocar && (NATIVO || !player.paused || document.body.classList.contains('is-loading'))) {

      pausarRadio();

    } else {

      iniciarStream(false);

    }

  });



  player.addEventListener('playing', () => {

    if (querTocar) {

      tentativasReconexao = 0;

      estaReconectando = false;

  
      atualizarEstadoUI('tocando');

    }

  });



  // Só reconecta imediatamente em erro fatal ou fim de stream (NÃO no 'stalled')

  player.addEventListener('error', agendarReconexao);

  player.addEventListener('ended', agendarReconexao);



  // Não usamos polling contínuo: navegadores limitam timers em segundo plano,
  // e verificações frequentes podem consumir bateria sem manter o áudio ativo.
  // O próprio elemento de áudio sinaliza falhas e tentamos recuperar ao retornar.
  player.addEventListener('pause', () => {
    if (pausaInterna) {
      pausaInterna = false;
      return;
    }
    if (querTocar && !estaReconectando) {
      clearTimeout(reconnectTimeout);
      reconnectTimeout = setTimeout(() => {
        if (querTocar && player.paused && navigator.onLine) agendarReconexao();
      }, 2500);
    }
  });

  window.addEventListener('pagehide', () => {
    // Intencionalmente não pausamos o áudio ao ocultar/fechar a visualização.
  });

  window.addEventListener('pageshow', () => {
    if (querTocar && player.paused && navigator.onLine) iniciarStream(true);
  });

  document.addEventListener('visibilitychange', () => {

    if (document.visibilityState === 'visible' && querTocar && player.paused && navigator.onLine) {

      iniciarStream(true);

    }

  });



  window.addEventListener('online', () => {

    iniciarMetadados();

    if (querTocar && (player.paused || estaReconectando)) {

      mostrarToast('Conexão restabelecida! Reconectando...');

      iniciarStream(true);

    }

  });



  window.addEventListener('offline', () => {

    if (querTocar) {

      atualizarEstadoUI('reconectando');

      mostrarToast('Sem conexão com a internet.');

    }

  });



  const volInicial = obterVolumeSalvo();

  volumeSlider.value = volInicial;

  player.volume = volInicial;



  volumeSlider.addEventListener('input', (e) => {

    const val = parseFloat(e.target.value);

    player.muted = val === 0;

    player.volume = val;

    localStorage.setItem('nj_volume', val);

    muteBtn.classList.toggle('mutado', player.muted);

  });



  muteBtn.addEventListener('click', () => {

    player.muted = !player.muted;

    muteBtn.classList.toggle('mutado', player.muted);

    if (!player.muted && player.volume === 0) {

      player.volume = 0.8;

      volumeSlider.value = 0.8;

      localStorage.setItem('nj_volume', 0.8);

    }

  });



  function iniciarMetadados() {

    if (!('EventSource' in window)) return;

    if (sseConexao && sseConexao.readyState !== EventSource.CLOSED) return;

    try {

      sseConexao = new EventSource(METADATA_SSE_URL);

      sseConexao.addEventListener('message', (event) => {

        try {

          const data = JSON.parse(event.data);

          const titulo = (data.streamTitle || '').trim();

          if (titulo && titulo.toLowerCase() !== 'unknown') {

            musicaAtual = titulo;

            npTitulo.textContent = titulo;

            if (querTocar) configurarMediaSession();

          }

        } catch (_) {}

      });

    } catch (_) {}

  }



  function fecharTodosSheets() {

    igrejaSheet.classList.remove('aberto');

    igrejaSheet.setAttribute('aria-hidden', 'true');

    timerSheet.classList.remove('aberto');

    timerSheet.setAttribute('aria-hidden', 'true');

    overlay.classList.remove('aberto');

  }



  igrejaBtn.addEventListener('click', () => {

    fecharTodosSheets();

    igrejaSheet.classList.add('aberto');

    igrejaSheet.setAttribute('aria-hidden', 'false');

    overlay.classList.add('aberto');

  });

  igrejaFechar.addEventListener('click', fecharTodosSheets);

  overlay.addEventListener('click', fecharTodosSheets);



  let timerInterval = null;

  let timerRestanteSeg = 0;



  function atualizarTimerUI() {

    if (timerRestanteSeg <= 0) {

      timerLabel.textContent = 'Timer';

      timerBtn.classList.remove('ativo');

      return;

    }

    const min = Math.floor(timerRestanteSeg / 60);

    const seg = String(timerRestanteSeg % 60).padStart(2, '0');

    timerLabel.textContent = `${min}:${seg}`;

    timerBtn.classList.add('ativo');

  }



  function definirTimer(minutos) {
    clearInterval(timerInterval);
    if (NATIVO) window.AndroidRadio.setSleepTimer(minutos > 0 ? minutos : 0);
    if (minutos <= 0) {
      timerRestanteSeg = 0;
      atualizarTimerUI();
      mostrarToast('Temporizador desativado.');
      return;
    }
    const fim = Date.now() + minutos * 60000;
    timerRestanteSeg = minutos * 60;
    atualizarTimerUI();
    mostrarToast(`A rádio desligará em ${minutos} minutos.`);

    timerInterval = setInterval(() => {
      timerRestanteSeg = Math.max(0, Math.ceil((fim - Date.now()) / 1000));
      atualizarTimerUI();
      if (timerRestanteSeg <= 0) {
        clearInterval(timerInterval);
        pausarRadio();
        mostrarToast('Temporizador encerrado. Boa noite!');
      }
    }, 1000);
  }

  timerBtn.addEventListener('click', () => {

    fecharTodosSheets();

    timerSheet.classList.add('aberto');

    timerSheet.setAttribute('aria-hidden', 'false');

    overlay.classList.add('aberto');

  });

  timerFechar.addEventListener('click', fecharTodosSheets);



  document.querySelectorAll('.timer_opcao').forEach((btn) => {

    btn.addEventListener('click', () => {

      definirTimer(parseInt(btn.dataset.min, 10));

      fecharTodosSheets();

    });

  });



  compartilharBtn.addEventListener('click', async () => {

    const shareData = {

      title: RADIO_NOME,

      text: 'Ouça a Web Rádio Nova Jerusalém ao vivo, 24 horas por dia!',

      url: window.location.href

    };

    if (NATIVO) {
      window.AndroidRadio.share(shareData.text + ' ' + SHARE_URL);
      return;
    }

    if (navigator.share) {

      try { await navigator.share(shareData); return; } catch (err) { if (err.name === 'AbortError') return; }

    }

    try {

      await navigator.clipboard.writeText(window.location.href);

      mostrarToast('Link copiado! Cole no WhatsApp para compartilhar.');

    } catch (_) {

      mostrarToast('Compartilhe este endereço: ' + window.location.href);

    }

  });



  const isStandalone = window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;

  const isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent);

  const isAndroid = /android/i.test(navigator.userAgent);



  if (!isStandalone && isIOS) instalarBtn.classList.add('show');



  window.addEventListener('beforeinstallprompt', (e) => {

    e.preventDefault();

    deferredPrompt = e;

    if (!isStandalone) instalarBtn.classList.add('show');

  });



  instalarBtn.addEventListener('click', async () => {

    if (deferredPrompt) {

      deferredPrompt.prompt();

      const { outcome } = await deferredPrompt.userChoice;

      if (outcome === 'accepted') instalarBtn.classList.remove('show');

      deferredPrompt = null;

    } else if (isIOS) {

      mostrarToast('No Safari: toque em Compartilhar e depois em "Adicionar à Tela de Início".', 5500);

    }

  });



  window.addEventListener('appinstalled', () => {

    instalarBtn.classList.remove('show');

    mostrarToast('Aplicativo instalado com sucesso!');

  });



  if (isStandalone && isAndroid && !localStorage.getItem('nj_bateria_ok')) {

    setTimeout(() => {

      bateriaCard.classList.add('show');

      bateriaCard.setAttribute('aria-hidden', 'false');

    }, 2200);

  }



  function dispensarBateria() {

    localStorage.setItem('nj_bateria_ok', '1');

    bateriaCard.classList.remove('show');

    bateriaCard.setAttribute('aria-hidden', 'true');

  }



  bateriaLiberar.addEventListener('click', dispensarBateria);

  bateriaDepois.addEventListener('click', dispensarBateria);



  if (!NATIVO && 'serviceWorker' in navigator) {

    window.addEventListener('load', () => {

      navigator.serviceWorker.register('./sw.js').catch(() => {});

    });

  }



  // Chamado pelo app Android sempre que o estado do player nativo muda
  window.nativeRadioState = (estado) => {
    if (estado === 'tocando') {
      querTocar = true;
      atualizarEstadoUI('tocando');
    } else if (estado === 'carregando') {
      querTocar = true;
      atualizarEstadoUI('carregando');
    } else {
      querTocar = false;
      atualizarEstadoUI('pausado');
    }
  };

  if (NATIVO) {
    // O volume é controlado pelos botões do aparelho
    const vw = document.getElementById('volume_wrap');
    if (vw) vw.style.display = 'none';
    try { window.nativeRadioState(window.AndroidRadio.getState()); } catch (_) {}
  }

  carregarVersiculoDoDia();

  iniciarMetadados();



  window.addEventListener('load', () => {

    setTimeout(() => splash.classList.add('sair'), 650);

  });

})();